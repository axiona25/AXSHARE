# TASK 2.5 — Key Derivation (Argon2id) + Test Suite Fase 2
> **Fase:** 2 — Crittografia & Key Management
> **Prerequisiti:** Task 2.4 completato
> **Path progetto:** `/Users/r.amoroso/Documents/Cursor/AXSHARE`
> **Output atteso:** `backend/app/crypto/kdf.py` completo + test suite completa Fase 2

---

## Prompt Cursor

```
Sei un senior security engineer. Il progetto AXSHARE si trova in
/Users/r.amoroso/Documents/Cursor/AXSHARE.

Devi implementare il modulo KDF (Key Derivation Function) con Argon2id.

RUOLO CRITICO DI QUESTO MODULO:
La derivazione della chiave dalla password e' il PUNTO PIU' CRITICO
del sistema zero-knowledge. Dalla password utente deriviamo:
1. La KEK (Key Encryption Key) per cifrare la chiave privata RSA
2. La KEK per cifrare la chiave privata X25519
Il server NON conosce la password, quindi NON puo' derivare la KEK,
quindi NON puo' decifrare nessuna chiave privata,
quindi NON puo' decifrare nessun file.

SCELTA ARGON2ID:
- Argon2id e' il winner del Password Hashing Competition 2015
- Resistente ad attacchi GPU, ASIC, side-channel
- Parametri OWASP 2024: memory=64MB, iterations=3, parallelism=4
- Usato per: derivazione KEK dalla password
- PBKDF2-SHA256 come fallback per compatibilita' (es. export)

════════════════════════════════════════════════
STEP 1 — Crea backend/app/crypto/kdf.py
════════════════════════════════════════════════

import os
import base64
import hashlib
import hmac
from dataclasses import dataclass
from argon2.low_level import hash_secret_raw, Type

# Parametri Argon2id OWASP 2024
ARGON2_MEMORY_COST = 65536   # 64 MB
ARGON2_TIME_COST = 3         # 3 iterazioni
ARGON2_PARALLELISM = 4       # 4 thread paralleli
ARGON2_HASH_LEN = 32         # 256 bit output (AES-256 key)
ARGON2_SALT_LEN = 32         # 256 bit salt

# Parametri PBKDF2 fallback
PBKDF2_ITERATIONS = 600_000  # OWASP 2024 raccomandazione
PBKDF2_HASH_LEN = 32


@dataclass
class DerivedKey:
    """Risultato della derivazione della chiave."""
    key: bytes              # chiave AES-256 derivata (32 bytes)
    salt: bytes             # salt usato (da salvare nel DB)
    algorithm: str          # "argon2id" o "pbkdf2"


def generate_salt() -> bytes:
    """Genera salt random per KDF. Deve essere unico per ogni utente."""
    return os.urandom(ARGON2_SALT_LEN)


def derive_key_from_password(
    password: str,
    salt: bytes | None = None,
    algorithm: str = "argon2id",
) -> DerivedKey:
    """
    Deriva una chiave AES-256 dalla password utente.

    IMPORTANTE: questa chiave viene usata per cifrare le chiavi private
    RSA e X25519 dell'utente. Non viene mai inviata al server.

    Args:
        password: password utente in chiaro (solo in memoria client-side)
        salt: salt da usare (se None viene generato automaticamente)
              Usare il salt salvato nel DB per ri-derivare la stessa chiave
        algorithm: "argon2id" (default) o "pbkdf2" (fallback)

    Returns:
        DerivedKey con key, salt e algorithm usato
    """
    if salt is None:
        salt = generate_salt()

    if algorithm == "argon2id":
        key = hash_secret_raw(
            secret=password.encode("utf-8"),
            salt=salt,
            time_cost=ARGON2_TIME_COST,
            memory_cost=ARGON2_MEMORY_COST,
            parallelism=ARGON2_PARALLELISM,
            hash_len=ARGON2_HASH_LEN,
            type=Type.ID,
        )
    elif algorithm == "pbkdf2":
        key = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            PBKDF2_ITERATIONS,
            dklen=PBKDF2_HASH_LEN,
        )
    else:
        raise ValueError(f"Algoritmo KDF non supportato: {algorithm}")

    return DerivedKey(key=key, salt=salt, algorithm=algorithm)


def derive_key_deterministic(
    password: str,
    salt: bytes,
    algorithm: str = "argon2id",
) -> bytes:
    """
    Deriva la stessa chiave dalla password e dal salt salvato nel DB.
    Usare per: ri-derivare la KEK al login per decifrare le chiavi private.

    Args:
        password: password utente
        salt: salt salvato nel DB alla registrazione (MAI cambiare)

    Returns:
        chiave AES-256 (stessa prodotta alla registrazione)
    """
    result = derive_key_from_password(password, salt=salt, algorithm=algorithm)
    return result.key


def hash_password_for_storage(password: str) -> str:
    """
    Hash della password per verifica login (separato dalla KEK derivation).
    Usa argon2-cffi che produce un hash con parametri embedded.

    NOTA: questo hash e' usato SOLO per verificare la password al login.
    NON e' la KEK — la KEK viene derivata separatamente con derive_key_from_password.

    Returns:
        hash Argon2id con formato "$argon2id$v=19$..."
    """
    from argon2 import PasswordHasher
    ph = PasswordHasher(
        memory_cost=ARGON2_MEMORY_COST,
        time_cost=ARGON2_TIME_COST,
        parallelism=ARGON2_PARALLELISM,
    )
    return ph.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verifica la password contro l'hash salvato nel DB.

    Returns:
        True se la password e' corretta
    """
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError
    ph = PasswordHasher()
    try:
        return ph.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError):
        return False


def needs_rehash(password_hash: str) -> bool:
    """
    Verifica se l'hash deve essere aggiornato (parametri obsoleti).
    Chiamare dopo ogni login riuscito.
    """
    from argon2 import PasswordHasher
    ph = PasswordHasher(
        memory_cost=ARGON2_MEMORY_COST,
        time_cost=ARGON2_TIME_COST,
        parallelism=ARGON2_PARALLELISM,
    )
    return ph.check_needs_rehash(password_hash)


def derive_session_key(user_id: str, session_id: str, master_secret: bytes) -> bytes:
    """
    Deriva una chiave di sessione effimera usando HMAC-SHA256.
    Usata per cifrare dati di sessione temporanei.
    Non e' persistente — viene ricalcolata ad ogni sessione.
    """
    message = f"{user_id}:{session_id}".encode("utf-8")
    return hmac.new(master_secret, message, hashlib.sha256).digest()


def secure_compare(a: bytes, b: bytes) -> bool:
    """
    Confronto di byte array in tempo costante.
    Previene timing attacks nella verifica di chiavi/token.
    """
    return hmac.compare_digest(a, b)

════════════════════════════════════════════════
STEP 2 — Aggiungi argon2-cffi a requirements.txt
════════════════════════════════════════════════

Aggiungi questa riga a backend/requirements.txt se non gia' presente:
argon2-cffi==23.1.0

Poi installa:
pip install argon2-cffi==23.1.0

════════════════════════════════════════════════
STEP 3 — Aggiorna backend/app/crypto/__init__.py
════════════════════════════════════════════════

Aggiungi agli import esistenti:

from app.crypto.kdf import (
    derive_key_from_password,
    derive_key_deterministic,
    hash_password_for_storage,
    verify_password,
    needs_rehash,
    generate_salt,
    secure_compare,
    DerivedKey,
)

E aggiungi al __all__:
"derive_key_from_password", "derive_key_deterministic",
"hash_password_for_storage", "verify_password", "needs_rehash",
"generate_salt", "secure_compare", "DerivedKey",

════════════════════════════════════════════════
STEP 4 — Crea backend/tests/phase2/test_kdf.py
════════════════════════════════════════════════

"""Test modulo KDF Argon2id — TASK 2.5"""
import os
import pytest
from app.crypto.kdf import (
    derive_key_from_password,
    derive_key_deterministic,
    hash_password_for_storage,
    verify_password,
    needs_rehash,
    generate_salt,
    secure_compare,
    ARGON2_HASH_LEN,
    ARGON2_SALT_LEN,
)


def test_generate_salt():
    salt = generate_salt()
    assert len(salt) == ARGON2_SALT_LEN
    assert generate_salt() != generate_salt()


def test_derive_key_argon2id():
    result = derive_key_from_password("password-sicura-2026")
    assert len(result.key) == ARGON2_HASH_LEN
    assert len(result.salt) == ARGON2_SALT_LEN
    assert result.algorithm == "argon2id"


def test_derive_key_deterministic():
    """Stessa password + stesso salt = stessa chiave."""
    salt = generate_salt()
    k1 = derive_key_deterministic("mia-password", salt)
    k2 = derive_key_deterministic("mia-password", salt)
    assert k1 == k2


def test_derive_key_different_passwords():
    """Password diverse producono chiavi diverse."""
    salt = generate_salt()
    k1 = derive_key_deterministic("password-A", salt)
    k2 = derive_key_deterministic("password-B", salt)
    assert k1 != k2


def test_derive_key_different_salts():
    """Salt diversi producono chiavi diverse (anche con stessa password)."""
    password = "stessa-password"
    k1 = derive_key_deterministic(password, generate_salt())
    k2 = derive_key_deterministic(password, generate_salt())
    assert k1 != k2


def test_derive_key_pbkdf2_fallback():
    result = derive_key_from_password("password", algorithm="pbkdf2")
    assert len(result.key) == 32
    assert result.algorithm == "pbkdf2"


def test_derive_key_invalid_algorithm():
    with pytest.raises(ValueError):
        derive_key_from_password("password", algorithm="md5")


def test_hash_password_for_storage():
    pw_hash = hash_password_for_storage("mia-password")
    assert pw_hash.startswith("$argon2id$")


def test_verify_password_correct():
    password = "password-corretta-2026"
    pw_hash = hash_password_for_storage(password)
    assert verify_password(password, pw_hash) is True


def test_verify_password_wrong():
    pw_hash = hash_password_for_storage("password-corretta")
    assert verify_password("password-sbagliata", pw_hash) is False


def test_needs_rehash():
    pw_hash = hash_password_for_storage("password")
    assert needs_rehash(pw_hash) is False


def test_secure_compare():
    a = os.urandom(32)
    b = os.urandom(32)
    assert secure_compare(a, a) is True
    assert secure_compare(a, b) is False


def test_kek_workflow():
    """
    Test workflow completo KEK:
    Registrazione -> salva salt nel DB
    Login -> ri-deriva KEK dalla password
    Usa KEK per cifrare/decifrare chiave privata RSA
    """
    from app.crypto.rsa import generate_keypair, encrypt_private_key, decrypt_private_key

    password = "password-utente-sicura-2026!"
    
    # Registrazione: deriva KEK e genera keypair
    derived = derive_key_from_password(password)
    kek = derived.key
    salt = derived.salt  # salvare nel DB
    
    keypair = generate_keypair()
    private_pem = keypair.private_key_pem()
    
    # Cifra la chiave privata con la KEK
    encrypted_private = encrypt_private_key(private_pem, kek)
    
    # Login: ri-deriva KEK dallo stesso salt
    kek_recovered = derive_key_deterministic(password, salt)
    assert kek_recovered == kek
    
    # Decifra la chiave privata con la KEK recuperata
    decrypted_private = decrypt_private_key(encrypted_private, kek_recovered)
    assert decrypted_private == private_pem

════════════════════════════════════════════════
STEP 5 — Crea backend/tests/phase2/test_phase2_full.py
════════════════════════════════════════════════

"""
Test suite completa Fase 2 — verifica integrazione tra tutti i moduli crypto
Eseguire con: pytest tests/phase2/ -v
"""
import os
import pytest
from app.crypto.aes import generate_file_key, encrypt, decrypt
from app.crypto.rsa import generate_keypair, encrypt_with_public_key, decrypt_with_private_key
from app.crypto.ecdh import generate_x25519_keypair, compute_shared_secret, derive_group_key
from app.crypto.kdf import derive_key_from_password, derive_key_deterministic
from app.crypto.vault import get_vault_service


def test_full_user_registration_crypto():
    """
    Simula il flusso crypto completo della registrazione utente:
    1. Deriva KEK dalla password (Argon2id)
    2. Genera keypair RSA-4096
    3. Genera keypair X25519
    4. Cifra entrambe le chiavi private con la KEK
    5. Verifica che tutto sia recuperabile al login
    """
    password = "password-sicura-registrazione"
    
    # 1. Deriva KEK
    derived = derive_key_from_password(password)
    kek = derived.key
    salt = derived.salt

    # 2. Genera keypair RSA
    from app.crypto.rsa import encrypt_private_key, decrypt_private_key
    rsa_kp = generate_keypair()
    encrypted_rsa_priv = encrypt_private_key(rsa_kp.private_key_pem(), kek)

    # 3. Genera keypair X25519
    from app.crypto.ecdh import encrypt_x25519_private_key, decrypt_x25519_private_key
    x25519_kp = generate_x25519_keypair()
    encrypted_x25519_priv = encrypt_x25519_private_key(x25519_kp.private_key_bytes(), kek)

    # 4. Simula login: ri-deriva KEK
    kek_login = derive_key_deterministic(password, salt)
    assert kek_login == kek

    # 5. Recupera chiavi private
    rsa_priv_recovered = decrypt_private_key(encrypted_rsa_priv, kek_login)
    assert rsa_priv_recovered == rsa_kp.private_key_pem()

    x25519_priv_recovered = decrypt_x25519_private_key(encrypted_x25519_priv, kek_login)
    assert x25519_priv_recovered == x25519_kp.private_key_bytes()


def test_full_file_upload_download_e2e():
    """
    Simula il flusso E2E completo upload/download file:
    1. Genera file_key
    2. Cifra file con AES-256-GCM
    3. Cifra file_key con RSA pubkey del proprietario
    4. Salva su "storage" (simulato in memoria)
    5. Proprietario scarica e decifra
    """
    owner = generate_keypair()
    file_content = b"Contenuto del documento riservato - CONFIDENTIAL"

    # Upload
    file_key = generate_file_key()
    encrypted_file = encrypt(file_content, file_key)
    encrypted_file_key = encrypt_with_public_key(file_key, owner.public_key_pem())

    # Download e decrypt
    recovered_file_key = decrypt_with_private_key(encrypted_file_key, owner.private_key_pem())
    from app.crypto.aes import EncryptedData
    enc = EncryptedData(
        ciphertext=encrypted_file.ciphertext,
        nonce=encrypted_file.nonce,
        key=recovered_file_key,
    )
    decrypted = decrypt(enc)
    assert decrypted == file_content


def test_full_group_sharing_e2e():
    """
    Simula condivisione in un gruppo con 3 utenti:
    - Owner carica file e condivide con il gruppo
    - Tutti i membri possono leggere il file
    - Utente rimosso non puo' leggere nuovi file
    """
    owner = generate_x25519_keypair()
    member1 = generate_x25519_keypair()
    member2 = generate_x25519_keypair()

    group_id = "gruppo-test-e2e"
    file_content = b"documento condiviso nel gruppo"

    # Owner carica il file
    file_key = generate_file_key()
    encrypted_file = encrypt(file_content, file_key)

    # Owner deriva group key per ogni membro
    salt1 = os.urandom(32)
    salt2 = os.urandom(32)
    shared1 = compute_shared_secret(owner.private_key, member1.public_key)
    shared2 = compute_shared_secret(owner.private_key, member2.public_key)
    gk1, _ = derive_group_key(shared1, group_id, salt=salt1)
    gk2, _ = derive_group_key(shared2, group_id, salt=salt2)

    # Cifra file_key per ogni membro
    from app.crypto.aes import encrypt_key, decrypt_key
    fk_for_m1 = encrypt_key(file_key, gk1)
    fk_for_m2 = encrypt_key(file_key, gk2)

    # Member1 decifra
    shared_m1 = compute_shared_secret(member1.private_key, owner.public_key)
    gk1_rec, _ = derive_group_key(shared_m1, group_id, salt=salt1)
    fk_m1 = decrypt_key(fk_for_m1, gk1_rec)
    from app.crypto.aes import EncryptedData
    enc = EncryptedData(ciphertext=encrypted_file.ciphertext, nonce=encrypted_file.nonce, key=fk_m1)
    assert decrypt(enc) == file_content

    # Member2 decifra
    shared_m2 = compute_shared_secret(member2.private_key, owner.public_key)
    gk2_rec, _ = derive_group_key(shared_m2, group_id, salt=salt2)
    fk_m2 = decrypt_key(fk_for_m2, gk2_rec)
    enc2 = EncryptedData(ciphertext=encrypted_file.ciphertext, nonce=encrypted_file.nonce, key=fk_m2)
    assert decrypt(enc2) == file_content

════════════════════════════════════════════════
STEP 6 — Esegui test suite completa Fase 2
════════════════════════════════════════════════

NOTA: assicurati che docker compose sia up (per i test Vault)
NOTA: i test RSA richiedono ~30 secondi per la generazione keypair

cd /Users/r.amoroso/Documents/Cursor/AXSHARE/backend
source .venv/bin/activate

# Assicurati che Vault sia attivo
docker compose up -d vault

# Esegui tutti i test Fase 2
pytest tests/phase2/ -v --tb=short

Output atteso:
  tests/phase2/test_aes.py          14 passed
  tests/phase2/test_rsa.py          11 passed
  tests/phase2/test_ecdh.py         11 passed
  tests/phase2/test_vault_kek.py     9 passed
  tests/phase2/test_kdf.py          14 passed
  tests/phase2/test_phase2_full.py   3 passed
  ─────────────────────────────────
  TOTALE                            62 passed

Al termine aggiorna la sezione Risultato di TASK-2.5-key-derivation.md
```

---

## Risultato
> *Compilare al completamento del task*

- Data completamento: ___
- test_aes: ___/14
- test_rsa: ___/11
- test_ecdh: ___/11
- test_vault_kek: ___/9
- test_kdf: ___/14
- test_phase2_full: ___/3
- **TOTALE: ___/62**
- Errori: ___
