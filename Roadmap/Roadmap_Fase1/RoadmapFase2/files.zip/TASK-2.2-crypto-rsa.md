# TASK 2.2 — Modulo Crypto RSA-4096
> **Fase:** 2 — Crittografia & Key Management
> **Prerequisiti:** Task 2.1 completato
> **Path progetto:** `/Users/r.amoroso/Documents/Cursor/AXSHARE`
> **Output atteso:** `backend/app/crypto/rsa.py` — generazione keypair, cifratura/decifratura, storage cifrato chiave privata

---

## Prompt Cursor

```
Sei un senior security engineer. Il progetto AXSHARE si trova in
/Users/r.amoroso/Documents/Cursor/AXSHARE.

Devi implementare il modulo RSA-4096 per:
- Generazione keypair per ogni utente al momento della registrazione
- Cifratura della file_key con la chiave pubblica del destinatario
  (permette la condivisione E2E senza mai esporre le chiavi)
- La chiave privata viene cifrata con AES-GCM derivato dalla password
  e salvata nel DB — il server non puo' mai decifrarla
- Firma digitale di hash (delegata a pyHanko in Fase 9, qui solo base)

PRINCIPIO ZERO-KNOWLEDGE:
Il server salva la chiave pubblica in chiaro (e' pubblica per definizione)
e la chiave privata CIFRATA con la KEK dell'utente derivata dalla password.
Il server non conosce mai la password, quindi non puo' mai decifrare
la chiave privata.

════════════════════════════════════════════════
STEP 1 — Crea backend/app/crypto/rsa.py
════════════════════════════════════════════════

import base64
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey, RSAPublicKey
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

RSA_KEY_SIZE = 4096
RSA_PUBLIC_EXPONENT = 65537


@dataclass
class RSAKeyPair:
    """Keypair RSA-4096 per un utente AXSHARE."""
    private_key: RSAPrivateKey
    public_key: RSAPublicKey

    def public_key_pem(self) -> str:
        """Chiave pubblica in formato PEM — salvabile nel DB in chiaro."""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")

    def private_key_pem(self) -> str:
        """
        Chiave privata in PEM NON cifrata.
        ATTENZIONE: usare solo in memoria, mai salvare in questa forma.
        Chiamare encrypt_private_key() prima di salvare.
        """
        return self.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf-8")


def generate_keypair() -> RSAKeyPair:
    """
    Genera keypair RSA-4096 per un nuovo utente.
    Chiamare una volta sola alla registrazione.
    La generazione richiede ~1-2 secondi — e' normale.
    """
    private_key = rsa.generate_private_key(
        public_exponent=RSA_PUBLIC_EXPONENT,
        key_size=RSA_KEY_SIZE,
        backend=default_backend(),
    )
    return RSAKeyPair(
        private_key=private_key,
        public_key=private_key.public_key(),
    )


def encrypt_with_public_key(plaintext: bytes, public_key_pem: str) -> str:
    """
    Cifra dati con chiave pubblica RSA (OAEP + SHA-256).
    USO: cifrare la file_key per un destinatario specifico.
    Limiti: max ~446 bytes per RSA-4096. Per file key (32 bytes) e' perfetto.

    Returns:
        ciphertext in base64
    """
    public_key = serialization.load_pem_public_key(
        public_key_pem.encode("utf-8"),
        backend=default_backend(),
    )
    ciphertext = public_key.encrypt(
        plaintext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    return base64.b64encode(ciphertext).decode("utf-8")


def decrypt_with_private_key(ciphertext_b64: str, private_key_pem: str) -> bytes:
    """
    Decifra dati con chiave privata RSA (OAEP + SHA-256).
    USO: recuperare la file_key cifrata con la propria chiave pubblica.

    Args:
        ciphertext_b64: ciphertext in base64
        private_key_pem: chiave privata PEM NON cifrata (gia' decifrata in memoria)
    """
    private_key = serialization.load_pem_private_key(
        private_key_pem.encode("utf-8"),
        password=None,
        backend=default_backend(),
    )
    ciphertext = base64.b64decode(ciphertext_b64)
    return private_key.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )


def encrypt_private_key(private_key_pem: str, aes_key: bytes) -> str:
    """
    Cifra la chiave privata RSA con AES-256-GCM prima di salvarla nel DB.
    L'AES key viene derivata dalla password utente (mai nota al server).

    Returns:
        chiave privata cifrata in base64 (nonce + ciphertext)
    """
    from app.crypto.aes import encrypt as aes_encrypt
    encrypted = aes_encrypt(private_key_pem.encode("utf-8"), aes_key)
    import base64
    return base64.b64encode(encrypted.to_storage_format()).decode("utf-8")


def decrypt_private_key(encrypted_private_key_b64: str, aes_key: bytes) -> str:
    """
    Decifra la chiave privata RSA dal DB usando la AES key derivata dalla password.
    Restituisce il PEM della chiave privata — usare solo in memoria.

    Args:
        encrypted_private_key_b64: chiave privata cifrata (dal DB)
        aes_key: chiave AES derivata dalla password utente

    Returns:
        PEM della chiave privata in chiaro (solo in memoria!)
    """
    from app.crypto.aes import EncryptedData, decrypt as aes_decrypt
    import base64
    data = base64.b64decode(encrypted_private_key_b64)
    encrypted = EncryptedData.from_storage_format(data, aes_key)
    return aes_decrypt(encrypted).decode("utf-8")


def load_public_key_from_pem(pem: str) -> RSAPublicKey:
    """Carica chiave pubblica da PEM."""
    return serialization.load_pem_public_key(
        pem.encode("utf-8"),
        backend=default_backend(),
    )


def load_private_key_from_pem(pem: str) -> RSAPrivateKey:
    """Carica chiave privata da PEM (non cifrata, gia' in memoria)."""
    return serialization.load_pem_private_key(
        pem.encode("utf-8"),
        password=None,
        backend=default_backend(),
    )


def sign_data(data: bytes, private_key_pem: str) -> str:
    """
    Firma dati con RSA-PSS + SHA-256.
    Usare per firme leggere su hash — per firma PDF completa usare pyHanko (Fase 9).

    Returns:
        firma in base64
    """
    private_key = load_private_key_from_pem(private_key_pem)
    signature = private_key.sign(
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )
    return base64.b64encode(signature).decode("utf-8")


def verify_signature(data: bytes, signature_b64: str, public_key_pem: str) -> bool:
    """
    Verifica firma RSA-PSS.

    Returns:
        True se la firma e' valida, False altrimenti
    """
    from cryptography.exceptions import InvalidSignature
    public_key = load_public_key_from_pem(public_key_pem)
    signature = base64.b64decode(signature_b64)
    try:
        public_key.verify(
            signature,
            data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH,
            ),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        return False

════════════════════════════════════════════════
STEP 2 — Aggiorna backend/app/crypto/__init__.py
════════════════════════════════════════════════

Aggiungi in fondo agli import esistenti:

from app.crypto.rsa import (
    generate_keypair,
    encrypt_with_public_key,
    decrypt_with_private_key,
    encrypt_private_key,
    decrypt_private_key,
    sign_data,
    verify_signature,
    RSAKeyPair,
)

E aggiungi al __all__:
"generate_keypair", "encrypt_with_public_key", "decrypt_with_private_key",
"encrypt_private_key", "decrypt_private_key", "sign_data", "verify_signature",
"RSAKeyPair",

════════════════════════════════════════════════
STEP 3 — Crea backend/tests/phase2/test_rsa.py
════════════════════════════════════════════════

"""Test modulo RSA-4096 — TASK 2.2"""
import pytest
from app.crypto.aes import generate_file_key
from app.crypto.rsa import (
    generate_keypair,
    encrypt_with_public_key,
    decrypt_with_private_key,
    encrypt_private_key,
    decrypt_private_key,
    sign_data,
    verify_signature,
    RSAKeyPair,
)


@pytest.fixture(scope="module")
def keypair() -> RSAKeyPair:
    """Genera keypair RSA una volta per tutti i test del modulo."""
    return generate_keypair()


def test_generate_keypair(keypair):
    assert keypair.private_key is not None
    assert keypair.public_key is not None
    pem = keypair.public_key_pem()
    assert pem.startswith("-----BEGIN PUBLIC KEY-----")
    priv_pem = keypair.private_key_pem()
    assert priv_pem.startswith("-----BEGIN PRIVATE KEY-----")


def test_keypair_uniqueness():
    """Due keypair generati devono essere diversi."""
    kp1 = generate_keypair()
    kp2 = generate_keypair()
    assert kp1.public_key_pem() != kp2.public_key_pem()


def test_encrypt_decrypt_file_key(keypair):
    """Cifra e decifra una file_key con RSA."""
    file_key = generate_file_key()  # 32 bytes
    encrypted = encrypt_with_public_key(file_key, keypair.public_key_pem())
    decrypted = decrypt_with_private_key(encrypted, keypair.private_key_pem())
    assert decrypted == file_key


def test_encrypt_decrypt_roundtrip(keypair):
    """Roundtrip con dati arbitrari."""
    data = b"chiave segreta da condividere"
    encrypted = encrypt_with_public_key(data, keypair.public_key_pem())
    assert isinstance(encrypted, str)
    decrypted = decrypt_with_private_key(encrypted, keypair.private_key_pem())
    assert decrypted == data


def test_wrong_private_key_fails():
    """Decifratura con chiave privata sbagliata deve fallire."""
    kp1 = generate_keypair()
    kp2 = generate_keypair()
    encrypted = encrypt_with_public_key(b"data", kp1.public_key_pem())
    with pytest.raises(Exception):
        decrypt_with_private_key(encrypted, kp2.private_key_pem())


def test_encrypt_decrypt_private_key(keypair):
    """La chiave privata cifrata con AES deve essere recuperabile."""
    aes_key = generate_file_key()
    private_pem = keypair.private_key_pem()
    encrypted_priv = encrypt_private_key(private_pem, aes_key)
    assert isinstance(encrypted_priv, str)
    decrypted_priv = decrypt_private_key(encrypted_priv, aes_key)
    assert decrypted_priv == private_pem


def test_decrypt_private_key_wrong_aes_key_fails(keypair):
    """Chiave privata cifrata non decifra con AES key sbagliata."""
    aes_key = generate_file_key()
    wrong_key = generate_file_key()
    encrypted_priv = encrypt_private_key(keypair.private_key_pem(), aes_key)
    with pytest.raises(Exception):
        decrypt_private_key(encrypted_priv, wrong_key)


def test_sign_verify(keypair):
    """Firma e verifica dati."""
    data = b"documento da firmare"
    signature = sign_data(data, keypair.private_key_pem())
    assert verify_signature(data, signature, keypair.public_key_pem()) is True


def test_verify_wrong_data_fails(keypair):
    """Verifica deve fallire se i dati sono stati modificati."""
    data = b"documento originale"
    signature = sign_data(data, keypair.private_key_pem())
    assert verify_signature(b"documento modificato", signature, keypair.public_key_pem()) is False


def test_verify_wrong_key_fails(keypair):
    """Verifica deve fallire con chiave pubblica sbagliata."""
    data = b"test"
    signature = sign_data(data, keypair.private_key_pem())
    wrong_kp = generate_keypair()
    assert verify_signature(data, signature, wrong_kp.public_key_pem()) is False


def test_e2e_file_sharing_flow():
    """
    Simula il flusso E2E completo:
    Utente A carica file -> cifra file_key con pubkey di B -> B decifra e accede al file
    """
    user_a = generate_keypair()
    user_b = generate_keypair()

    # A genera chiave del file
    file_key = generate_file_key()

    # A cifra il file (simulato)
    from app.crypto.aes import encrypt as aes_encrypt, decrypt as aes_decrypt
    plaintext = b"contenuto del file riservato"
    encrypted_file = aes_encrypt(plaintext, file_key)

    # A condivide con B: cifra file_key con pubkey di B
    file_key_for_b = encrypt_with_public_key(file_key, user_b.public_key_pem())

    # B riceve e decifra la file_key con la propria chiave privata
    recovered_file_key = decrypt_with_private_key(file_key_for_b, user_b.private_key_pem())
    assert recovered_file_key == file_key

    # B decifra il file
    from app.crypto.aes import EncryptedData
    enc_with_b_key = EncryptedData(
        ciphertext=encrypted_file.ciphertext,
        nonce=encrypted_file.nonce,
        key=recovered_file_key,
    )
    decrypted = aes_decrypt(enc_with_b_key)
    assert decrypted == plaintext

════════════════════════════════════════════════
STEP 4 — Esegui test
════════════════════════════════════════════════

NOTA: i test RSA sono piu' lenti degli AES per via della generazione keypair.
Attendi fino a 30 secondi.

cd /Users/r.amoroso/Documents/Cursor/AXSHARE/backend
source .venv/bin/activate
pytest tests/phase2/test_rsa.py -v

Output atteso: 11 passed

Al termine aggiorna la sezione Risultato di TASK-2.2-crypto-rsa.md
```

---

## Risultato
> *Compilare al completamento del task*

- Data completamento: ___
- Test passati: ___/11
- Tempo generazione keypair: ___s
- Errori: ___
