# TASK 2.1 — Modulo Crypto AES-256-GCM
> **Fase:** 2 — Crittografia & Key Management
> **Prerequisiti:** Fase 1 completata
> **Path progetto:** `/Users/r.amoroso/Documents/Cursor/AXSHARE`
> **Output atteso:** `backend/app/crypto/aes.py` completo e testato

---

## Prompt Cursor

```
Sei un senior security engineer. Il progetto AXSHARE si trova in
/Users/r.amoroso/Documents/Cursor/AXSHARE.

Devi implementare il modulo AES-256-GCM per la cifratura simmetrica
dei file e delle chiavi. Questo e' il cuore della cifratura E2E di AXSHARE.

PRINCIPI FONDAMENTALI:
- Ogni file ha la propria chiave AES-256 generata randomicamente
- La cifratura avviene SEMPRE lato client prima dell'upload
- Il server riceve e salva SOLO blob cifrati, mai contenuto in chiaro
- IV/nonce e' sempre random (12 bytes per GCM), mai riutilizzato
- Il tag di autenticazione GCM garantisce integrita' e autenticita'

════════════════════════════════════════════════
STEP 1 — Crea backend/app/crypto/aes.py
════════════════════════════════════════════════

import os
import base64
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

AES_KEY_SIZE = 32       # 256 bit
AES_NONCE_SIZE = 12     # 96 bit (standard GCM)
AES_TAG_SIZE = 16       # 128 bit (tag autenticazione GCM)


@dataclass
class EncryptedData:
    """Contenitore per dati cifrati con AES-256-GCM."""
    ciphertext: bytes
    nonce: bytes
    key: bytes

    def to_storage_format(self) -> bytes:
        """Formato: [12 bytes nonce][N bytes ciphertext+tag]"""
        return self.nonce + self.ciphertext

    @classmethod
    def from_storage_format(cls, data: bytes, key: bytes) -> "EncryptedData":
        nonce = data[:AES_NONCE_SIZE]
        ciphertext = data[AES_NONCE_SIZE:]
        return cls(ciphertext=ciphertext, nonce=nonce, key=key)

    def nonce_b64(self) -> str:
        return base64.b64encode(self.nonce).decode("utf-8")

    def key_b64(self) -> str:
        return base64.b64encode(self.key).decode("utf-8")


def generate_file_key() -> bytes:
    """Genera chiave AES-256 random. Ogni file DEVE avere la propria chiave."""
    return os.urandom(AES_KEY_SIZE)


def generate_nonce() -> bytes:
    """Genera nonce random per AES-GCM. MAI riutilizzare."""
    return os.urandom(AES_NONCE_SIZE)


def encrypt(plaintext: bytes, key: bytes, aad: bytes | None = None) -> EncryptedData:
    """
    Cifra dati con AES-256-GCM.
    aad: Additional Authenticated Data — non cifrata ma autenticata.
    Usare file_id come aad per legare il ciphertext al file specifico.
    """
    if len(key) != AES_KEY_SIZE:
        raise ValueError(f"Chiave AES deve essere {AES_KEY_SIZE} bytes, ricevuto {len(key)}")
    nonce = generate_nonce()
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, aad)
    return EncryptedData(ciphertext=ciphertext, nonce=nonce, key=key)


def decrypt(encrypted: EncryptedData, aad: bytes | None = None) -> bytes:
    """
    Decifra dati con AES-256-GCM.
    Solleva InvalidTag se dati manomessi, chiave sbagliata o AAD errato.
    """
    aesgcm = AESGCM(encrypted.key)
    return aesgcm.decrypt(encrypted.nonce, encrypted.ciphertext, aad)


def decrypt_raw(ciphertext: bytes, nonce: bytes, key: bytes, aad: bytes | None = None) -> bytes:
    """Decifra passando ciphertext, nonce e key separatamente."""
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, aad)


def encrypt_string(plaintext: str, key: bytes, aad: bytes | None = None) -> str:
    """Cifra stringa, restituisce base64(nonce+ciphertext). Per nomi file e metadati."""
    encrypted = encrypt(plaintext.encode("utf-8"), key, aad)
    return base64.b64encode(encrypted.to_storage_format()).decode("utf-8")


def decrypt_string(encrypted_b64: str, key: bytes, aad: bytes | None = None) -> str:
    """Decifra stringa cifrata con encrypt_string."""
    data = base64.b64decode(encrypted_b64)
    encrypted = EncryptedData.from_storage_format(data, key)
    return decrypt(encrypted, aad).decode("utf-8")


def encrypt_key(key_to_wrap: bytes, wrapping_key: bytes) -> str:
    """Key wrapping locale: cifra una chiave con un'altra. Restituisce base64."""
    encrypted = encrypt(key_to_wrap, wrapping_key)
    return base64.b64encode(encrypted.to_storage_format()).decode("utf-8")


def decrypt_key(wrapped_key_b64: str, wrapping_key: bytes) -> bytes:
    """Decifra una chiave wrappata con encrypt_key."""
    data = base64.b64decode(wrapped_key_b64)
    encrypted = EncryptedData.from_storage_format(data, wrapping_key)
    return decrypt(encrypted)


def derive_key_from_bytes(master: bytes, salt: bytes, info: bytes = b"axshare-file-key") -> bytes:
    """Deriva chiave AES-256 da master secret con HKDF-SHA256."""
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives import hashes
    hkdf = HKDF(algorithm=hashes.SHA256(), length=AES_KEY_SIZE, salt=salt, info=info)
    return hkdf.derive(master)

════════════════════════════════════════════════
STEP 2 — Aggiorna backend/app/crypto/__init__.py
════════════════════════════════════════════════

from app.crypto.aes import (
    generate_file_key, generate_nonce, encrypt, decrypt, decrypt_raw,
    encrypt_string, decrypt_string, encrypt_key, decrypt_key,
    derive_key_from_bytes, EncryptedData, AES_KEY_SIZE, AES_NONCE_SIZE,
)

__all__ = [
    "generate_file_key", "generate_nonce", "encrypt", "decrypt", "decrypt_raw",
    "encrypt_string", "decrypt_string", "encrypt_key", "decrypt_key",
    "derive_key_from_bytes", "EncryptedData", "AES_KEY_SIZE", "AES_NONCE_SIZE",
]

════════════════════════════════════════════════
STEP 3 — Crea backend/tests/phase2/__init__.py
════════════════════════════════════════════════

File vuoto.

════════════════════════════════════════════════
STEP 4 — Crea backend/tests/phase2/test_aes.py
════════════════════════════════════════════════

"""Test modulo AES-256-GCM — TASK 2.1"""
import os
import pytest
from cryptography.exceptions import InvalidTag

from app.crypto.aes import (
    generate_file_key, generate_nonce, encrypt, decrypt, decrypt_raw,
    encrypt_string, decrypt_string, encrypt_key, decrypt_key,
    derive_key_from_bytes, EncryptedData, AES_KEY_SIZE, AES_NONCE_SIZE,
)


def test_generate_file_key():
    key = generate_file_key()
    assert len(key) == AES_KEY_SIZE
    assert generate_file_key() != generate_file_key()


def test_generate_nonce():
    nonce = generate_nonce()
    assert len(nonce) == AES_NONCE_SIZE
    assert generate_nonce() != generate_nonce()


def test_encrypt_decrypt_roundtrip():
    key = generate_file_key()
    plaintext = b"AXSHARE test content cifrato"
    assert decrypt(encrypt(plaintext, key)) == plaintext


def test_encrypt_decrypt_with_aad():
    key = generate_file_key()
    plaintext = b"file content"
    aad = b"file-id-12345"
    assert decrypt(encrypt(plaintext, key, aad=aad), aad=aad) == plaintext


def test_decrypt_wrong_aad_fails():
    key = generate_file_key()
    encrypted = encrypt(b"data", key, aad=b"correct")
    with pytest.raises(InvalidTag):
        decrypt(encrypted, aad=b"wrong")


def test_decrypt_wrong_key_fails():
    key = generate_file_key()
    wrong_key = generate_file_key()
    encrypted = encrypt(b"data", key)
    wrong = EncryptedData(ciphertext=encrypted.ciphertext, nonce=encrypted.nonce, key=wrong_key)
    with pytest.raises(InvalidTag):
        decrypt(wrong)


def test_decrypt_tampered_ciphertext_fails():
    key = generate_file_key()
    encrypted = encrypt(b"original", key)
    tampered = bytearray(encrypted.ciphertext)
    tampered[0] ^= 0xFF
    bad = EncryptedData(ciphertext=bytes(tampered), nonce=encrypted.nonce, key=key)
    with pytest.raises(InvalidTag):
        decrypt(bad)


def test_nonce_uniqueness():
    key = generate_file_key()
    enc1 = encrypt(b"same", key)
    enc2 = encrypt(b"same", key)
    assert enc1.nonce != enc2.nonce
    assert enc1.ciphertext != enc2.ciphertext


def test_storage_format_roundtrip():
    key = generate_file_key()
    plaintext = b"test storage"
    encrypted = encrypt(plaintext, key)
    stored = encrypted.to_storage_format()
    recovered = EncryptedData.from_storage_format(stored, key)
    assert decrypt(recovered) == plaintext


def test_encrypt_decrypt_string():
    key = generate_file_key()
    original = "documento_segreto_2026.pdf"
    assert decrypt_string(encrypt_string(original, key), key) == original


def test_encrypt_decrypt_key():
    wrapping_key = generate_file_key()
    file_key = generate_file_key()
    assert decrypt_key(encrypt_key(file_key, wrapping_key), wrapping_key) == file_key


def test_derive_key_from_bytes():
    master = os.urandom(32)
    salt = os.urandom(32)
    k1 = derive_key_from_bytes(master, salt)
    k2 = derive_key_from_bytes(master, salt)
    assert k1 == k2
    assert len(k1) == AES_KEY_SIZE
    assert k1 != derive_key_from_bytes(master, os.urandom(32))


def test_invalid_key_size():
    with pytest.raises(ValueError):
        encrypt(b"data", b"short")


def test_large_file_encryption():
    key = generate_file_key()
    large = os.urandom(10 * 1024 * 1024)
    assert decrypt(encrypt(large, key)) == large


def test_decrypt_raw():
    key = generate_file_key()
    plaintext = b"decrypt raw test"
    enc = encrypt(plaintext, key)
    assert decrypt_raw(enc.ciphertext, enc.nonce, key) == plaintext

════════════════════════════════════════════════
STEP 5 — Esegui test
════════════════════════════════════════════════

cd /Users/r.amoroso/Documents/Cursor/AXSHARE/backend
source .venv/bin/activate
pytest tests/phase2/test_aes.py -v

Output atteso: 14 passed

Al termine aggiorna la sezione Risultato di TASK-2.1-crypto-aes.md
```

---

## Risultato
> *Compilare al completamento del task*

- Data completamento: ___
- Test passati: ___/14
- Errori: ___
