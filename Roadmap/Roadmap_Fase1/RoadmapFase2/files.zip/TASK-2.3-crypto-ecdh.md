# TASK 2.3 — Modulo Crypto X25519 ECDH (Key Exchange Gruppi)
> **Fase:** 2 — Crittografia & Key Management
> **Prerequisiti:** Task 2.2 completato
> **Path progetto:** `/Users/r.amoroso/Documents/Cursor/AXSHARE`
> **Output atteso:** `backend/app/crypto/ecdh.py` — scambio chiavi X25519 per gruppi e condivisione E2E

---

## Prompt Cursor

```
Sei un senior security engineer. Il progetto AXSHARE si trova in
/Users/r.amoroso/Documents/Cursor/AXSHARE.

Devi implementare il modulo X25519 ECDH per lo scambio di chiavi nei gruppi.

PERCHE' X25519 E NON SOLO RSA:
- RSA-4096 e' lento e pesante per scambi frequenti
- X25519 e' piu' veloce, chiavi piu' corte, sicurezza equivalente
- Usato per: shared secret nei gruppi, forward secrecy nelle sessioni
- Il shared secret viene poi usato con HKDF per derivare chiavi AES
- Principio: ogni membro del gruppo ha la propria coppia X25519
  e puo' derivare lo stesso shared secret senza che il server lo conosca

════════════════════════════════════════════════
STEP 1 — Crea backend/app/crypto/ecdh.py
════════════════════════════════════════════════

import os
import base64
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives import serialization


@dataclass
class X25519KeyPair:
    """Coppia di chiavi X25519 per ECDH."""
    private_key: X25519PrivateKey
    public_key: X25519PublicKey

    def public_key_bytes(self) -> bytes:
        """Chiave pubblica raw (32 bytes) — salvabile nel DB in chiaro."""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def public_key_b64(self) -> str:
        """Chiave pubblica in base64 per storage nel DB."""
        return base64.b64encode(self.public_key_bytes()).decode("utf-8")

    def private_key_bytes(self) -> bytes:
        """
        Chiave privata raw (32 bytes).
        MAI salvare in chiaro — cifrare con AES prima di salvare nel DB.
        """
        return self.private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def private_key_b64(self) -> str:
        """Chiave privata in base64 — solo in memoria, mai salvare cosi'."""
        return base64.b64encode(self.private_key_bytes()).decode("utf-8")


def generate_x25519_keypair() -> X25519KeyPair:
    """
    Genera coppia di chiavi X25519 per un utente.
    Molto piu' veloce di RSA-4096.
    Generare una volta per utente, come per RSA.
    """
    private_key = X25519PrivateKey.generate()
    return X25519KeyPair(
        private_key=private_key,
        public_key=private_key.public_key(),
    )


def compute_shared_secret(
    my_private_key: X25519PrivateKey | bytes,
    their_public_key: X25519PublicKey | bytes,
) -> bytes:
    """
    Calcola lo shared secret ECDH tra due parti.

    Il shared secret e' lo stesso per entrambe le parti:
    Alice: compute(alice_private, bob_public) == secret
    Bob:   compute(bob_private, alice_public) == secret

    Il server non conosce mai le chiavi private, quindi
    non puo' calcolare il shared secret.

    Args:
        my_private_key: chiave privata X25519 (oggetto o bytes raw)
        their_public_key: chiave pubblica X25519 dell'altro (oggetto o bytes raw)

    Returns:
        shared secret (32 bytes) — usare con HKDF per derivare chiave AES
    """
    if isinstance(my_private_key, bytes):
        my_private_key = X25519PrivateKey.from_private_bytes(my_private_key)
    if isinstance(their_public_key, bytes):
        their_public_key = X25519PublicKey.from_public_bytes(their_public_key)

    return my_private_key.exchange(their_public_key)


def derive_group_key(
    shared_secret: bytes,
    group_id: str,
    salt: bytes | None = None,
) -> bytes:
    """
    Deriva una chiave AES-256 per un gruppo dal shared secret ECDH.

    Args:
        shared_secret: output di compute_shared_secret
        group_id: ID del gruppo (usato come contesto HKDF)
        salt: salt random (se None viene generato automaticamente)

    Returns:
        tuple (group_key: bytes, salt: bytes)
        Il salt DEVE essere salvato nel DB per permettere la ri-derivazione.
    """
    from app.crypto.aes import derive_key_from_bytes
    if salt is None:
        salt = os.urandom(32)
    info = f"axshare-group-{group_id}".encode("utf-8")
    group_key = derive_key_from_bytes(shared_secret, salt, info)
    return group_key, salt


def encrypt_x25519_private_key(private_key_bytes: bytes, aes_key: bytes) -> str:
    """
    Cifra la chiave privata X25519 con AES-256-GCM prima del salvataggio.
    L'AES key viene derivata dalla password utente.
    """
    from app.crypto.aes import encrypt as aes_encrypt
    encrypted = aes_encrypt(private_key_bytes, aes_key)
    return base64.b64encode(encrypted.to_storage_format()).decode("utf-8")


def decrypt_x25519_private_key(encrypted_b64: str, aes_key: bytes) -> bytes:
    """
    Decifra la chiave privata X25519 dal DB.
    Restituisce i bytes raw della chiave privata.
    """
    from app.crypto.aes import EncryptedData, decrypt as aes_decrypt
    data = base64.b64decode(encrypted_b64)
    encrypted = EncryptedData.from_storage_format(data, aes_key)
    return aes_decrypt(encrypted)


def load_public_key_from_bytes(raw: bytes) -> X25519PublicKey:
    """Carica chiave pubblica X25519 da bytes raw."""
    return X25519PublicKey.from_public_bytes(raw)


def load_public_key_from_b64(b64: str) -> X25519PublicKey:
    """Carica chiave pubblica X25519 da base64."""
    return load_public_key_from_bytes(base64.b64decode(b64))


def load_private_key_from_bytes(raw: bytes) -> X25519PrivateKey:
    """Carica chiave privata X25519 da bytes raw."""
    return X25519PrivateKey.from_private_bytes(raw)

════════════════════════════════════════════════
STEP 2 — Aggiorna backend/app/crypto/__init__.py
════════════════════════════════════════════════

Aggiungi agli import esistenti:

from app.crypto.ecdh import (
    generate_x25519_keypair,
    compute_shared_secret,
    derive_group_key,
    encrypt_x25519_private_key,
    decrypt_x25519_private_key,
    load_public_key_from_b64,
    X25519KeyPair,
)

E aggiungi al __all__:
"generate_x25519_keypair", "compute_shared_secret", "derive_group_key",
"encrypt_x25519_private_key", "decrypt_x25519_private_key",
"load_public_key_from_b64", "X25519KeyPair",

════════════════════════════════════════════════
STEP 3 — Crea backend/tests/phase2/test_ecdh.py
════════════════════════════════════════════════

"""Test modulo X25519 ECDH — TASK 2.3"""
import os
import pytest
from app.crypto.aes import generate_file_key
from app.crypto.ecdh import (
    generate_x25519_keypair,
    compute_shared_secret,
    derive_group_key,
    encrypt_x25519_private_key,
    decrypt_x25519_private_key,
    load_public_key_from_b64,
    X25519KeyPair,
)


def test_generate_keypair():
    kp = generate_x25519_keypair()
    assert len(kp.public_key_bytes()) == 32
    assert len(kp.private_key_bytes()) == 32


def test_keypair_uniqueness():
    kp1 = generate_x25519_keypair()
    kp2 = generate_x25519_keypair()
    assert kp1.public_key_b64() != kp2.public_key_b64()


def test_shared_secret_symmetry():
    """Alice e Bob devono ottenere lo stesso shared secret."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    secret_alice = compute_shared_secret(
        alice.private_key,
        bob.public_key,
    )
    secret_bob = compute_shared_secret(
        bob.private_key,
        alice.public_key,
    )
    assert secret_alice == secret_bob
    assert len(secret_alice) == 32


def test_shared_secret_from_bytes():
    """Shared secret calcolabile anche da bytes raw."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    secret1 = compute_shared_secret(
        alice.private_key_bytes(),
        bob.public_key_bytes(),
    )
    secret2 = compute_shared_secret(
        alice.private_key,
        bob.public_key,
    )
    assert secret1 == secret2


def test_different_pairs_different_secrets():
    """Coppie diverse producono shared secret diversi."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    carol = generate_x25519_keypair()
    secret_ab = compute_shared_secret(alice.private_key, bob.public_key)
    secret_ac = compute_shared_secret(alice.private_key, carol.public_key)
    assert secret_ab != secret_ac


def test_derive_group_key():
    """Derivazione chiave gruppo da shared secret."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    shared = compute_shared_secret(alice.private_key, bob.public_key)
    group_id = "gruppo-test-123"
    key, salt = derive_group_key(shared, group_id)
    assert len(key) == 32
    assert len(salt) == 32


def test_derive_group_key_deterministic():
    """Stessi input producono stessa chiave (deterministica con salt fisso)."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    shared = compute_shared_secret(alice.private_key, bob.public_key)
    salt = os.urandom(32)
    key1, _ = derive_group_key(shared, "gruppo-123", salt=salt)
    key2, _ = derive_group_key(shared, "gruppo-123", salt=salt)
    assert key1 == key2


def test_derive_group_key_different_groups():
    """Gruppi diversi producono chiavi diverse (anche con stesso shared secret)."""
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    shared = compute_shared_secret(alice.private_key, bob.public_key)
    salt = os.urandom(32)
    key1, _ = derive_group_key(shared, "gruppo-A", salt=salt)
    key2, _ = derive_group_key(shared, "gruppo-B", salt=salt)
    assert key1 != key2


def test_encrypt_decrypt_private_key():
    """Chiave privata X25519 cifrata con AES deve essere recuperabile."""
    kp = generate_x25519_keypair()
    aes_key = generate_file_key()
    encrypted = encrypt_x25519_private_key(kp.private_key_bytes(), aes_key)
    recovered = decrypt_x25519_private_key(encrypted, aes_key)
    assert recovered == kp.private_key_bytes()


def test_load_public_key_from_b64():
    """Caricamento chiave pubblica da base64."""
    kp = generate_x25519_keypair()
    b64 = kp.public_key_b64()
    loaded = load_public_key_from_b64(b64)
    assert loaded.public_bytes_raw() == kp.public_key_bytes()


def test_e2e_group_flow():
    """
    Simula flusso completo gruppo con 3 membri:
    - Alice crea il gruppo e genera la chiave gruppo
    - Bob e Carol ricevono la chiave cifrata con ECDH
    - Tutti decifrano e ottengono la stessa chiave gruppo
    """
    alice = generate_x25519_keypair()
    bob = generate_x25519_keypair()
    carol = generate_x25519_keypair()

    group_id = "gruppo-progetto-x"

    # Alice calcola shared secret con Bob e deriva la group key per Bob
    secret_ab = compute_shared_secret(alice.private_key, bob.public_key)
    salt_b = os.urandom(32)
    group_key_for_b, _ = derive_group_key(secret_ab, group_id, salt=salt_b)

    # Alice calcola shared secret con Carol e deriva la group key per Carol
    secret_ac = compute_shared_secret(alice.private_key, carol.public_key)
    salt_c = os.urandom(32)
    group_key_for_c, _ = derive_group_key(secret_ac, group_id, salt=salt_c)

    # Cifra il file con la group key di Alice (come owner)
    from app.crypto.aes import generate_file_key, encrypt as aes_enc, decrypt as aes_dec
    file_key = generate_file_key()
    from app.crypto.aes import encrypt_key, decrypt_key
    file_key_for_b = encrypt_key(file_key, group_key_for_b)
    file_key_for_c = encrypt_key(file_key, group_key_for_c)

    # Bob recupera la group key e decifra la file_key
    secret_ba = compute_shared_secret(bob.private_key, alice.public_key)
    group_key_b_recovered, _ = derive_group_key(secret_ba, group_id, salt=salt_b)
    assert decrypt_key(file_key_for_b, group_key_b_recovered) == file_key

    # Carol recupera la group key e decifra la file_key
    secret_ca = compute_shared_secret(carol.private_key, alice.public_key)
    group_key_c_recovered, _ = derive_group_key(secret_ca, group_id, salt=salt_c)
    assert decrypt_key(file_key_for_c, group_key_c_recovered) == file_key

════════════════════════════════════════════════
STEP 4 — Esegui test
════════════════════════════════════════════════

cd /Users/r.amoroso/Documents/Cursor/AXSHARE/backend
source .venv/bin/activate
pytest tests/phase2/test_ecdh.py -v

Output atteso: 11 passed

Al termine aggiorna la sezione Risultato di TASK-2.3-crypto-ecdh.md
```

---

## Risultato
> *Compilare al completamento del task*

- Data completamento: ___
- Test passati: ___/11
- Errori: ___
