# TASK 2.4 — KEK Wrapping/Unwrapping su Vault
> **Fase:** 2 — Crittografia & Key Management
> **Prerequisiti:** Task 2.3 completato, Vault in esecuzione con Transit engine attivo
> **Path progetto:** `/Users/r.amoroso/Documents/Cursor/AXSHARE`
> **Output atteso:** `backend/app/crypto/vault.py` aggiornato con workflow completo KEK + test integrazione Vault

---

## Prompt Cursor

```
Sei un senior security engineer. Il progetto AXSHARE si trova in
/Users/r.amoroso/Documents/Cursor/AXSHARE.

Il file backend/app/crypto/vault.py esiste gia' dalla Fase 1 (Task 1.5).
Devi ESTENDERLO con il workflow completo di Key Encryption Key (KEK)
per la gestione sicura delle chiavi dei file.

ARCHITETTURA KEK IN AXSHARE:

  File plaintext
      |
      v
  AES-256-GCM (file_key)          <- generata random per ogni file
      |
      v
  Ciphertext (su MinIO)

  file_key
      |
      v
  Cifrata con KEK utente           <- derivata da password utente (Argon2id)
  o RSA pubkey utente
      |
      v
  Salvata nel DB (colonna file_key_encrypted)

  KEK master (Vault Transit)       <- protegge le KEK di sistema/gruppo
      |
      v
  Wrap/unwrap chiavi di gruppo e chiavi di sistema

Il server non vede mai:
  - file_key in chiaro
  - KEK utente (derivata dalla password che il server non conosce)
  - Contenuto dei file

Il server gestisce tramite Vault:
  - Wrapping delle chiavi di SISTEMA (non delle chiavi utente)
  - Rotazione periodica delle KEK di sistema

════════════════════════════════════════════════
STEP 1 — Estendi backend/app/crypto/vault.py
════════════════════════════════════════════════

Aggiungi questi metodi alla classe VaultService esistente:

    # ─── File Key Management ─────────────────────────────────

    def store_file_key_wrapped(self, file_id: str, file_key: bytes) -> str:
        """
        Wrappa una file_key con la KEK master di Vault e la salva nel KV.
        Usare per file di sistema o file senza proprietario specifico.

        NOTA: per file utente normali, la file_key viene cifrata con
        la chiave pubblica RSA dell'utente, NON con Vault.
        Vault viene usato per chiavi di sistema e backup sicuro.

        Returns:
            ciphertext Vault (formato "vault:v1:...")
        """
        ciphertext = self.wrap_key(file_key)
        self.write_secret(
            f"file_keys/{file_id}",
            {"wrapped_key": ciphertext, "version": 1},
        )
        return ciphertext

    def retrieve_file_key(self, file_id: str) -> bytes:
        """
        Recupera e unwrappa la file_key di un file di sistema da Vault.
        """
        secret = self.read_secret(f"file_keys/{file_id}")
        if not secret:
            raise KeyError(f"File key non trovata in Vault per file_id: {file_id}")
        return self.unwrap_key(secret["wrapped_key"])

    def delete_file_key(self, file_id: str) -> None:
        """
        Elimina la file_key dal Vault — usare per auto-distruzione.
        Dopo questa operazione il file e' irrecuperabile.
        """
        self.delete_secret(f"file_keys/{file_id}")
        import structlog
        structlog.get_logger().warning(
            "File key permanently deleted from Vault",
            file_id=file_id,
        )

    # ─── Group Key Management ────────────────────────────────

    def store_group_master_key(self, group_id: str, group_key: bytes) -> str:
        """
        Wrappa e salva la chiave master di un gruppo in Vault.
        Usata come KEK per le chiavi dei file condivisi nel gruppo.

        Returns:
            ciphertext Vault
        """
        ciphertext = self.wrap_key(group_key)
        self.write_secret(
            f"groups/{group_id}/master_key",
            {
                "wrapped_key": ciphertext,
                "version": 1,
            },
        )
        return ciphertext

    def retrieve_group_master_key(self, group_id: str) -> bytes:
        """Recupera la chiave master di un gruppo da Vault."""
        secret = self.read_secret(f"groups/{group_id}/master_key")
        if not secret:
            raise KeyError(f"Group key non trovata per group_id: {group_id}")
        return self.unwrap_key(secret["wrapped_key"])

    def delete_group_keys(self, group_id: str) -> None:
        """
        Elimina tutte le chiavi di un gruppo da Vault.
        Usare quando il gruppo viene dissolto — tutti i file diventeranno
        inaccessibili.
        """
        self.delete_secret(f"groups/{group_id}/master_key")
        import structlog
        structlog.get_logger().warning(
            "Group keys permanently deleted",
            group_id=group_id,
        )

    # ─── Key Rotation ────────────────────────────────────────

    def rewrap_file_key(self, file_id: str) -> None:
        """
        Re-cifra la file_key con la versione piu' recente della KEK master.
        Chiamare dopo ogni rotazione della master key.
        """
        secret = self.read_secret(f"file_keys/{file_id}")
        if not secret:
            return
        new_ciphertext = self.rewrap_key(secret["wrapped_key"])
        self.write_secret(
            f"file_keys/{file_id}",
            {
                "wrapped_key": new_ciphertext,
                "version": secret.get("version", 1) + 1,
            },
        )

    def batch_rewrap_keys(self, path_prefix: str) -> int:
        """
        Re-cifra tutte le chiavi sotto un path prefix dopo key rotation.

        Returns:
            numero di chiavi re-cifrate
        """
        keys = self.list_secrets(path_prefix)
        count = 0
        for key_path in keys:
            try:
                full_path = f"{path_prefix}/{key_path}".rstrip("/")
                secret = self.read_secret(full_path)
                if secret and "wrapped_key" in secret:
                    new_ciphertext = self.rewrap_key(secret["wrapped_key"])
                    self.write_secret(
                        full_path,
                        {**secret, "wrapped_key": new_ciphertext},
                    )
                    count += 1
            except Exception as e:
                import structlog
                structlog.get_logger().error(
                    "Failed to rewrap key",
                    path=key_path,
                    error=str(e),
                )
        return count

    # ─── GDPR — Right to Erasure ─────────────────────────────

    def erase_all_user_data(self, user_id: str) -> dict:
        """
        GDPR Art. 17 — Diritto alla cancellazione.
        Elimina TUTTI i segreti dell'utente da Vault:
        - Chiavi pubbliche
        - File keys dell'utente
        - Membership nei gruppi

        Dopo questa operazione i file dell'utente sono IRRECUPERABILI.

        Returns:
            report di cancellazione
        """
        import structlog
        logger = structlog.get_logger()
        deleted = []

        # 1. Chiavi pubbliche
        try:
            self.delete_user_keys(user_id)
            deleted.append("public_keys")
        except Exception:
            pass

        # 2. File keys utente
        try:
            file_keys = self.list_secrets(f"file_keys/user/{user_id}")
            for key in file_keys:
                self.delete_secret(f"file_keys/user/{user_id}/{key}")
                deleted.append(f"file_key/{key}")
        except Exception:
            pass

        logger.warning(
            "GDPR erasure completed",
            user_id=user_id,
            deleted_items=deleted,
        )
        return {"user_id": user_id, "deleted": deleted, "status": "erased"}

════════════════════════════════════════════════
STEP 2 — Crea backend/tests/phase2/test_vault_kek.py
════════════════════════════════════════════════

"""
Test KEK wrapping/unwrapping su Vault — TASK 2.4
Richiede Vault in esecuzione su localhost:8200
Eseguire con: pytest tests/phase2/test_vault_kek.py -v
"""
import os
import uuid
import pytest
from app.crypto.aes import generate_file_key
from app.crypto.vault import get_vault_service


@pytest.fixture(scope="module")
def vault():
    return get_vault_service()


def test_vault_authenticated(vault):
    assert vault.client.is_authenticated()


def test_wrap_unwrap_file_key(vault):
    """Wrap e unwrap di una file_key AES-256."""
    file_key = generate_file_key()
    ciphertext = vault.wrap_key(file_key)
    assert ciphertext.startswith("vault:v")
    recovered = vault.unwrap_key(ciphertext)
    assert recovered == file_key


def test_store_retrieve_file_key(vault):
    """Store e retrieve di file_key via KV + Transit."""
    file_id = str(uuid.uuid4())
    file_key = generate_file_key()
    vault.store_file_key_wrapped(file_id, file_key)
    recovered = vault.retrieve_file_key(file_id)
    assert recovered == file_key
    # Cleanup
    vault.delete_file_key(file_id)


def test_delete_file_key(vault):
    """Dopo delete, la file_key non deve essere recuperabile."""
    file_id = str(uuid.uuid4())
    file_key = generate_file_key()
    vault.store_file_key_wrapped(file_id, file_key)
    vault.delete_file_key(file_id)
    with pytest.raises(KeyError):
        vault.retrieve_file_key(file_id)


def test_store_retrieve_group_key(vault):
    """Store e retrieve di group master key."""
    group_id = str(uuid.uuid4())
    group_key = generate_file_key()
    vault.store_group_master_key(group_id, group_key)
    recovered = vault.retrieve_group_master_key(group_id)
    assert recovered == group_key
    # Cleanup
    vault.delete_group_keys(group_id)


def test_delete_group_keys(vault):
    """Dopo delete, la group key non deve essere recuperabile."""
    group_id = str(uuid.uuid4())
    vault.store_group_master_key(group_id, generate_file_key())
    vault.delete_group_keys(group_id)
    with pytest.raises(KeyError):
        vault.retrieve_group_master_key(group_id)


def test_rewrap_file_key(vault):
    """Re-wrap di una file_key deve restituire la stessa chiave."""
    file_id = str(uuid.uuid4())
    file_key = generate_file_key()
    vault.store_file_key_wrapped(file_id, file_key)
    vault.rewrap_file_key(file_id)
    recovered = vault.retrieve_file_key(file_id)
    assert recovered == file_key
    # Cleanup
    vault.delete_file_key(file_id)


def test_gdpr_erasure(vault):
    """GDPR erasure deve eliminare tutti i segreti dell'utente."""
    user_id = str(uuid.uuid4())
    # Crea alcune chiavi per l'utente
    vault.store_user_public_key(user_id, "fake-public-key-pem", key_type="rsa")
    result = vault.erase_all_user_data(user_id)
    assert result["status"] == "erased"
    assert "public_keys" in result["deleted"]
    # Verifica che le chiavi siano state eliminate
    assert vault.get_user_public_key(user_id) is None


def test_wrap_unwrap_roundtrip_multiple_keys(vault):
    """Test con piu' chiavi diverse — nessuna collisione."""
    keys = [generate_file_key() for _ in range(5)]
    wrapped = [vault.wrap_key(k) for k in keys]
    # Tutti i ciphertext devono essere diversi
    assert len(set(wrapped)) == 5
    # Tutti devono essere recuperabili correttamente
    for original, ciphertext in zip(keys, wrapped):
        recovered = vault.unwrap_key(ciphertext)
        assert recovered == original

════════════════════════════════════════════════
STEP 3 — Esegui test
════════════════════════════════════════════════

NOTA: richiede Vault in esecuzione (docker compose up -d vault)

cd /Users/r.amoroso/Documents/Cursor/AXSHARE/backend
source .venv/bin/activate
pytest tests/phase2/test_vault_kek.py -v

Output atteso: 9 passed

Al termine aggiorna la sezione Risultato di TASK-2.4-key-wrapping.md
```

---

## Risultato
> *Compilare al completamento del task*

- Data completamento: ___
- Test passati: ___/9
- Vault Transit operativo: ___
- Errori: ___
